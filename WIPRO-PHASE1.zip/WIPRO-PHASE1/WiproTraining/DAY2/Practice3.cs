﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class Practice3
//    {
//        static void Main(string[] args)
//        {
            //Addition of matrices
            //Console.Write("Enter row length: ");
            //int rows = int.Parse(Console.ReadLine());
            //Console.Write("Enter column length: ");
            //int cols = int.Parse(Console.ReadLine());

            //int[,] matrix1 = new int[rows, cols];
            //int[,] matrix2 = new int[rows, cols];
            //int[,] resultMatrix = new int[rows, cols];

            //Console.WriteLine("Enter Elements for 1st matrix:");
            //for (int i = 0; i < rows; i++)
            //{
            //    for (int j = 0; j < cols; j++)
            //    {
            //        matrix1[i, j] = int.Parse(Console.ReadLine());
            //    }
            //}

            //Console.WriteLine("Enter Elements for 2nd matrix:");
            //for (int i = 0; i < rows; i++)
            //{
            //        for (int j = 0; j < cols; j++)
            //        {
            //            matrix2[i, j] = int.Parse(Console.ReadLine());
            //        }
            //    }

            //    Console.WriteLine("Matrix 1 is:");
            //    PrintMatrix(matrix1, rows, cols);

            //    Console.WriteLine("Matrix 2 is:");
            //    PrintMatrix(matrix2, rows, cols);

            //    Console.WriteLine("Addition of matrices is:");
            //    for (int i = 0; i < rows; i++)
            //    {
            //        for (int j = 0; j < cols; j++)
            //        {
            //            resultMatrix[i, j] = matrix1[i, j] + matrix2[i, j];
            //        }
            //    }
            //    PrintMatrix(resultMatrix, rows, cols);
            //}

            //static void PrintMatrix(int[,] matrix, int rows, int cols)
            //{
            //    for (int i = 0; i < rows; i++)
            //    {
            //        for (int j = 0; j < cols; j++)
            //        {
            //            Console.Write(matrix[i, j] + " ");
            //        }
            //        Console.WriteLine();
            //    }






            //Mult of matrices

//            Console.Write("Enter row length: ");
//            int rows = int.Parse(Console.ReadLine());
//            Console.Write("Enter column length: ");
//            int cols = int.Parse(Console.ReadLine());

//            int[,] matrix1 = new int[rows, cols];
//            int[,] matrix2 = new int[cols, rows];
//            int[,] resultMatrix = new int[rows, rows];

//            Console.WriteLine("Enter Elements for 1st matrix:");
//            for (int i = 0; i < rows; i++)
//            {
//                for (int j = 0; j < cols; j++)
//                {
//                    matrix1[i, j] = int.Parse(Console.ReadLine());
//                }
//            }

//            Console.WriteLine("Enter Elements for 2nd matrix:");
//            for (int i = 0; i < cols; i++)
//            {
//                for (int j = 0; j < rows; j++)
//                {
//                    matrix2[i, j] = int.Parse(Console.ReadLine());
//                }
//            }

//            Console.WriteLine("Matrix 1 is:");
//            PrintMatrix(matrix1, rows, cols);

//            Console.WriteLine("Matrix 2 is:");
//            PrintMatrix(matrix2, cols, rows);

//            Console.WriteLine("Multiplication of matrices is:");
//            for (int i = 0; i < rows; i++)
//            {
//                for (int j = 0; j < rows; j++)
//                {
//                    resultMatrix[i, j] = 0;
//                    for (int k = 0; k < cols; k++)
//                    {
//                        resultMatrix[i, j] += matrix1[i, k] * matrix2[k, j];
//                    }
//                }
//            }
//            PrintMatrix(resultMatrix, rows, rows);
//        }

//        static void PrintMatrix(int[,] matrix, int rows, int cols)
//        {
//            for (int i = 0; i < rows; i++)
//            {
//                for (int j = 0; j < cols; j++)
//                {
//                    Console.Write(matrix[i, j] + " ");
//                }
//                Console.WriteLine();
//            }

//        }
//    }
//}

