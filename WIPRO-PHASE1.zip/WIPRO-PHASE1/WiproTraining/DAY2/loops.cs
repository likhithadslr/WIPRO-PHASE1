﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class loops
//    {
//        static void Main(string[] args)
//        {
            //for (int i=0;i<10;i++)
            //{
            //    Console.WriteLine(i);
            //}


            //WHILE LOOP

            //int a = 10;
            //while (a >= 10)
            //{
            //    Console.WriteLine("Welcome");  //infinite times welcome
            //    a++;
            //}
            //while (a <= 10)
            //{
            //    Console.WriteLine("Welcome");  //once welcome output
            //    a++;
            //}
            //while (a == 10)
            //{
            //    Console.WriteLine("Welcome");   //one welcome
            //    a++;
            //}
            //while (a > 10)
            //{
            //    Console.WriteLine("Welcome"); //No output
            //    a++;
            //}
            //while (a >= 10)
            //{
            //    Console.WriteLine("Welcome"); //one welcome
            //    a--;
            //}
            //while (a == 10)
            //{
            //    Console.WriteLine("Welcome"); //one welcome
            //    a--;
            //}



            //DO-WHILE LOOP

            //do
            //{
            //    Console.WriteLine("Welcome"); //Infinite welcome
            //} while (true);

            //int b = 10;
            //do
            //{
            //    Console.WriteLine("India is the best country");
            //} while (b != 10);


//        }
//    }
//}
