﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class Practice2
//    {
//        static void Main(string[] args)
//        {
            //display even from 1-100

            //for

            //for (int i = 2; i <= 100; i += 2)
            //{
            //    Console.Write(i + " ");
            //}

            //display odd from 1-100

            //while

            //int i = 1; 
            //while (i <= 100)
            //{
            //    Console.Write(i + " ");
            //    i += 2; 
            //}

            //display numbers divisible by 5 from 1-100

            //for (int i = 5; i <= 100;i+=5)
            //{
            //    Console.WriteLine(i+" ");
            //}

            //int i = 0;
            //do
            //{
            //    Console.Write(i + " ");
            //    i += 5;
            //} while (i <= 100);


            //accept min,max from user and display all numbers between them 

            //Console.Write("Enter the min: ");
            //int min = Convert.ToInt32(Console.ReadLine());

            //Console.Write("Enter the max: ");
            //int max = Convert.ToInt32(Console.ReadLine());

            //for (int i = min; i < max; i++)
            //{
            //    Console.Write(i + " ");
            //}

            //Fibonacci from 1-50
            //int a = 0, b = 1, num = 0;

            //while (num <= 50)
            //{
            //    if (num >= 0) Console.Write(num + " ");
            //    num = a + b;
            //    a = b;
            //    b = num;
            //}


            //display num fro 50-1

            //for (int i = 50; i >= 1; i --)
            //{
            //    Console.Write(i+" ");
            //}


            //multiplication table of accepted number

            //Console.Write("Enter a number: ");
            //int number = Convert.ToInt32(Console.ReadLine());

            //for (int i = 1; i <= 10; i++)
            //{
            //    Console.WriteLine($"{number} x {i} = {number * i}");
            //}

//        }

//    }
//}
