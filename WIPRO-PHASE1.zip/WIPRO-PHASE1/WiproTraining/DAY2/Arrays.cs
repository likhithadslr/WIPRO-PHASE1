﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class Arrays
//    {
//        static void Main(string[] args)
//        {
            //            int[] arr = new int[10];
            //            arr[0] = 1;
            //            arr[1] = 12;
            //            arr[2] = 11;
            //            arr[3] = 19;
            //            arr[4] = 121;
            //            arr[5] = 15;
            //            arr[6] = 18;
            //            arr[7] = 10;
            //            arr[8] = 13;
            //            arr[9] = 14;

            //            for (int i = 0; i < arr.Length; i++)
            //            {
            //                Console.WriteLine(arr[i]);
            //            }
            //            //declaration
            //            int[] arr1 = { 11, 14, 12, 17 };
            //            for (int i = 0; i < arr1.Length; i++)
            //            {
            //                Console.WriteLine(arr1[i]);
            //            }
            //            //declaration
            //            int[] arr2 = new int[5] { 1,12, 17, 3, 23 };
            //            for (int i = 0; i < arr2.Length; i++)
            //            {
            //                Console.WriteLine(arr2[i]);
            //            }

            //DOUBLE DIMENSIONAL ARRAYS
            //            int[,] arr = new int[2, 2]
            //                    {
            //                        {4,2},
            //                        {1,4}
            //                   };
            //            Console.WriteLine("Double dimensional array");
            //            for (int i=0;i<arr.GetLength(0);i++)
            //            {
            //                for (int j = 0; j < arr.GetLength(1); j++)
            //                {
            //                    Console.WriteLine(arr[i, j]);
            //                }
            //            }


            //For-each loop
            //            int[] arr1 = new int[4] { 1, 3, 5, 7 };
            //            foreach (int i in arr1)
            //            {
            //                Console.WriteLine(i);
            //            }

            //Jagged array
            //int[][] arr1=new  int[3][];
            //arr1[0] = new int[3] { 1, 2, 3 };
            //arr1[1] = new int[2] { 4, 5 };
            //arr1[2] = new int[4] { 6, 7, 8, 9 };
            //OR
            //arr1[0] = new int[3] ;
            //arr1[1] = new int[2];
            //arr1[2] = new int[4];

            //arr1[0][0] = 1;
            //arr1[0][1] = 2;
            //arr1[0][2] = 3;

            //arr1[1][0] = 4;
            //arr1[1][1] = 5;

            //arr1[2][0] = 6;
            //arr1[2][1] = 7;
            //arr1[2][2] = 8;
            //arr1[2][3] = 9;

//            Console.WriteLine("array elements:");

//            foreach (var item in arr1)
//            {
//                Console.WriteLine(item);
//            }

//        }
//    }
//}
