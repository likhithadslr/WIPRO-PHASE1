﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class switchcase_demo
//    {
//        static void Main(string[] args)
//        {
//            int num = int.Parse(Console.ReadLine());
//            switch (num)
//            {
//                case 1:
//                    Console.WriteLine("Number is 1");
//                    break;
//                case 2:
//                    Console.WriteLine("Number is 2");
//                    break;
//                case 3:
//                    Console.WriteLine("Number is 3");
//                    break;
//                default:
//                    Console.WriteLine("Please enter between 1 to 3");
//                    break;
//            }
//        }
//    }
//}

