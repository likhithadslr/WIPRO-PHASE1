﻿//using System;

//namespace WiproTraining.DAY2
//{
//    internal class Practiceques1
//    {
//        static void Main(string[] args)
//        {
            //Enter day num and give day name
            //Console.WriteLine("Enter a day number:");
            //int dayNumb=int.Parse(Console.ReadLine());
            //switch (dayNumb)
            //{
            //    case 1: Console.WriteLine("Day is sunday");
            //        break;
            //    case 2: Console.WriteLine("Day is Monday");
            //        break;
            //    case 3: Console.WriteLine("Day is Tuesday");
            //        break;
            //    case 4:
            //        Console.WriteLine("Day is Wednesday");
            //        break;
            //    case 5:
            //        Console.WriteLine("Day is Thursday");
            //        break;
            //    case 6:
            //        Console.WriteLine("Day is Friday");
            //        break;
            //    case 7:
            //        Console.WriteLine("Day is Saturday");
            //        break;
            //    default: Console.WriteLine("pls enter between 1 to 7");
            //        break;

            //Enter day name and give number
            //Console.WriteLine("Enter a day name:");
            //string dayName = Console.ReadLine();
            //switch (dayName)
            //{
            //    case "sunday":
            //        Console.WriteLine("Day is 1");
            //        break;
            //    case "Monday":
            //        Console.WriteLine("Day is 2");
            //        break;
            //    case "Tuesday":
            //        Console.WriteLine("Day is 3");
            //        break;
            //    case "Wednesday":
            //        Console.WriteLine("Day is 4");
            //        break;
            //    case "Thursday":
            //        Console.WriteLine("Day is 5");
            //        break;
            //    case "Friday":
            //        Console.WriteLine("Day is 6");
            //        break;
            //    case "Saturday":
            //        Console.WriteLine("Day is 7");
            //        break;
            //    default:
            //        Console.WriteLine("pls enter between sunday to saturday");
            //        break;
            //}

            //Enter month num and display month name
            //Console.WriteLine("Enter a monht num:");
            //int monthNum = Console.ReadLine();
            //switch (monthNum)
            //{
            //    case 1: Console.WriteLine("Month is Jan");
            //        break;
            //    case 2: Console.WriteLine("Feb month");
            //        break;
            //    case 3: Console.WriteLine("Month is march");
            //        break;
            //    case 4:
            //        Console.WriteLine("month is april");
            //        break;
            //    case 5:
            //        Console.WriteLine("month is may");
            //        break;
            //    case 6:
            //        Console.WriteLine("month is june");
            //        break;
            //    case 7:
            //        Console.WriteLine("month is july ");
            //        break;
            //    case 8: Console.WriteLine("Month is Aug");
            //        break;
            //    case 9:
            //        Console.WriteLine("month is Sep");
            //        break;
            //    case 10:
            //        Console.WriteLine("month is Oct");
            //        break;
            //    case 11:
            //        Console.WriteLine("month is Nov");
            //        break;
            //    case 12:
            //        Console.WriteLine("month is Dec");
            //        break;
            //    default: Console.WriteLine("pls enter between 1 to 12");
            //        break;

            //give operator calculate result
            //int num1;
            //int num2;

            //Console.WriteLine("Enter first num:");
            //num1=int.Parse(Console.ReadLine());
            //Console.WriteLine("Enter 2nd");
            //num2=Convert.ToInt32(Console.ReadLine());

            //char op=char.Parse(Console.ReadLine());

            //switch (op)
            //{
            //    case '+': Console.WriteLine(num1 + num2);
            //        break;
            //    case '-':
            //        Console.WriteLine(num1 - num2);
            //        break;
            //    case '*':
            //        Console.WriteLine(num1 * num2);
            //        break;
            //    default: Console.WriteLine("pls enter a valid operator");
            //        break;

            //}
       
//            }
//        }
//}
