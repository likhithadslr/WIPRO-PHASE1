﻿//using System;


//namespace WiproTraining.DAY1
//{
//    internal class Sample
//    {
//        static void Main(string[] args)
//        {
//            Console.Write("Hi this is my C# program");
//            Console.WriteLine("Welcome to .Net training");


//            //Console.Read();  //enter key in same line 
//            //Console.ReadKey(); //Any key
//            //Console.ReadLine(); //enter key in different
//        }
//    }
//}


