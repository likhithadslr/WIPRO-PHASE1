using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CoreApp_Wipro.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
