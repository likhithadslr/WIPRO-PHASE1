﻿//using System;
//public class BasicMaths1
//{
//    public double Add(double num1, double num2)
//    {
//        return num1 + num2;
//    }
//    public double Substract(double num1, double num2)
//    {
//        return num1 - num2;
//    }
//    public double divide(double num1, double num2)
//    {
//        return num1 / num2;
//    }
//    public double Multiply(double num1, double num2)
//    {
//        return num1 + num2;
//    }
//    BasicMaths1 obj = new BasicMaths1();
//    Console.WriteLine(obj.Add(1, 2));
//    Console.WriteLine(obj.Substract(3, 4));
//    Console.WriteLine(obj.Multiply(5, 6));
//    Console.WriteLine(obj.divide(5, 6));
//}

