﻿//using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;

//namespace UnitTestProject1
//{
//    [TestClass]
//    public class UnitTest1
//    {
//        [TestMethod]
//        public void TestMethod1()
//        {
//                BasicMaths bm = new BasicMaths();
//                double res = bm.Add(10, 10);
//                Assert.AreEqual(res, 20);

//        }
//    }
//}

//using Microsoft.VisualStudio.TestTools.UnitTesting;
//using System;

//[TestClass]
//public class UnitTest1
//{
//    [TestMethod]
//    public void Test_AddMethod()
//    {
//        BasicMaths1 bm = new BasicMaths1();
//        double res = bm.Add(10, 10);
//        Assert.AreEqual(res, 200);
//    }
//}
